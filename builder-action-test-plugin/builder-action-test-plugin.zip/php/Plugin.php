<?php

namespace ImaginaryMachines\BuilderTest;

class Plugin
{

    public function sayHi(): string
    {
        return  'Hi Roy';
    }
}
